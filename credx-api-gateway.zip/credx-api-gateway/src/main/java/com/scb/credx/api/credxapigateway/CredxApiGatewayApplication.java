package com.scb.credx.api.credxapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CredxApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CredxApiGatewayApplication.class, args);
	}

}

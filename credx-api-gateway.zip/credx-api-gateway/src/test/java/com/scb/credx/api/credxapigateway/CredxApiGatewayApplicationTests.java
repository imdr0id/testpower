package com.scb.credx.api.credxapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CredxApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
